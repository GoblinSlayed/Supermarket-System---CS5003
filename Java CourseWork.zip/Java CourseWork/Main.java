import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        SupermarketSystem system = new SupermarketSystem(); // Creating an instance of the SupermarketSystem class to manage products and the activities 
        Scanner scanner = new Scanner(System.in); 
        int choice; 

        do {
            System.out.println("\n===== SUPERMARKET MANAGEMENT SYSTEM =====");
            // Below are a list of prompts asking for the user to pick a choice from the menu 
            System.out.println("1. Add Product");
            System.out.println("2. Display All Products"); 
            System.out.println("3. Delete Product"); 
            System.out.println("4. Add Activity (Update Stock)"); 
            System.out.println("5. Show Last 4 Activities (Sorted)"); 
            System.out.println("6. Exit"); 
            System.out.print("Enter your choice: "); 
            choice = scanner.nextInt(); // Reads the user's choice as an integer 
            scanner.nextLine(); 

            switch (choice) {   // Switch statements to handle the different options in the menu, more efficient than multiple if-else statements

                case 1:
                    System.out.print("Enter Product ID: ");
                    String id = scanner.nextLine(); 

                    System.out.print("Enter Product Name: "); 
                    String name = scanner.nextLine();

                    System.out.print("Enter Entry Date: "); 
                    String date = scanner.nextLine();

                    System.out.print("Enter Quantity: ");
                    int qty = scanner.nextInt();
                    scanner.nextLine();

                    Product p = new Product(id, name, date, qty);
                    system.addProduct(p);
                    System.out.println("Product added successfully!");
                    break;

                case 2:
                    system.displayProducts();
                    break;

                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    String deleteID = scanner.nextLine();

                    boolean removed = system.deleteProduct(deleteID);

                    if (removed) {
                        System.out.println("Product deleted.");
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter Product ID: ");
                    String pid = scanner.nextLine();

                    System.out.print("Enter Activity ID: ");
                    String actID = scanner.nextLine();

                    System.out.print("Enter Activity Type (AddToStock / RemoveFromStock): ");
                    String actType = scanner.nextLine();

                    System.out.print("Enter Quantity: ");
                    int actQty = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter Activity Date: ");
                    String actDate = scanner.nextLine();

                    Activity activity = new Activity(actID, actType, actQty, actDate);
                    system.updateStock(pid, activity);
                    break;

                case 5:
                    System.out.print("Enter Product ID: ");
                    String productID = scanner.nextLine();

                    Product prod = system.getProduct(productID);

                    if (prod == null) {
                        System.out.println("Product not found!");
                    } else {
                        Activity[] acts = prod.getActivities().getAllActivities();

                        // Sort using your sorting algorithm (we will add next)
                        sortActivitiesByQuantity(acts);

                        System.out.println("\n--- Sorted Activities ---");
                        for (Activity a : acts) {
                            System.out.println(
                                a.getActivityID() + " | " +
                                a.getActivityName() + " | Qty: " +
                                a.getActivityQty() + " | Date: " +
                                a.getActivityDate()
                            );
                        }
                    }
                    break;

                case 6:
                    System.out.println("Exiting system...");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 6);

        scanner.close();
    }



    
    // SORTING ALGORITHM FOR THE ACTIVITIES 
    // Bubble Sort (simple and works well on 4 items)
    
    public static void sortActivitiesByQuantity(Activity[] arr) { 

        if (arr == null || arr.length <= 1)
            return;

        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j].getActivityQty() > arr[j + 1].getActivityQty()) {

                    // Swap
                    Activity temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;

                }
            }
        }
    }
}
