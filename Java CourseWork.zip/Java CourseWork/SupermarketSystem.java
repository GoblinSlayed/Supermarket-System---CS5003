import java.util.ArrayList;

public class SupermarketSystem {

    private ArrayList<Product> products;

    public SupermarketSystem() {
        products = new ArrayList<Product>();
    }

    // Adds a product
    public void addProduct(Product product) {
        products.add(product);
    }

    // Using Linear search to fine the product by their ID

    public int searchProductByID(String productID) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProductID().equals(productID)) {
                return i;
            }
        }
        return -1;
    }

    
    public Product getProduct(String productID) {
        int index = searchProductByID(productID);
        if (index != -1) {
            return products.get(index);
        }
        return null;
    }

    // Delete product
    public boolean deleteProduct(String productID) {
        int index = searchProductByID(productID);
        if (index != -1) {
            products.remove(index);
            return true;
        }
        return false;
    }

    // Display all products
    public void displayProducts() {
        if (products.isEmpty()) {
            System.out.println("No products in the system.");
            return;
        }

        System.out.println("\n--- Product List ---");
        for (Product p : products) {
            System.out.println(
                "ID: " + p.getProductID() +
                " | Name: " + p.getProductName() +
                " | Entry Date: " + p.getEntryDate() +
                " | Quantity: " + p.getProductQty()
            );
        }
    }

    // Update stock + add activity
    public void updateStock(String productID, Activity activity) {
        Product p = getProduct(productID);

        if (p == null) {
            System.out.println("Product not found.");
            return;
        }

        p.addActivity(activity);  // Add to circular queue 

        if (activity.getActivityName().equalsIgnoreCase("AddToStock")) {
            p.setProductQty(p.getProductQty() + activity.getActivityQty());
        } else if (activity.getActivityName().equalsIgnoreCase("RemoveFromStock")) {
            p.setProductQty(p.getProductQty() - activity.getActivityQty());
        }

        System.out.println("Stock updated successfully!");
    }
}
