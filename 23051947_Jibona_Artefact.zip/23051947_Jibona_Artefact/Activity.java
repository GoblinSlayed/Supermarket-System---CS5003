public class Activity {

    private String activityID;
    private String activityName;
    private int activityQty;
    private String activityDate;

    public Activity(String activityID, String activityName, int activityQty, String activityDate) {
        this.activityID = activityID;
        this.activityName = activityName;
        this.activityQty = activityQty;
        this.activityDate = activityDate;
    }

    public String getActivityID() {
        return activityID;
    }

    public String getActivityName() {
        return activityName;
    }

    public int getActivityQty() {
        return activityQty;
    }

    public String getActivityDate() {
        return activityDate;
    }
}

