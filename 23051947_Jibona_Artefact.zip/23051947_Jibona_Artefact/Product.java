
public class Product {

    private String productID;
    private String productName;
    private String entryDate;
    private int quantity;

    private ActivityQueue activities; // Stores last 4 activities

    // Constructor
    public Product(String productID, String productName, String entryDate, int quantity) {
        this.productID = productID;
        this.productName = productName;
        this.entryDate = entryDate;
        this.quantity = quantity;
        this.activities = new ActivityQueue(4); // last 4
    }

    // ===== Getters =====

    public String getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public String getEntryDate() {
        return entryDate;
    }

    // Main.java expects this name
    public int getProductQty() {
        return quantity;
    }

    // Main.java expects this name
    public void setProductQty(int quantity) {
        this.quantity = quantity;
    }

    public ActivityQueue getActivities() {
        return activities;
    }

    // Main.java calls this
    public void addActivity(Activity activity) {
        activities.enqueue(activity);
    }
}
