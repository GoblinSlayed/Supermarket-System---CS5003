public class ActivityQueue {

    private Activity[] queue;
    private int front;
    private int rear;
    private int size;
    private int capacity;

    public ActivityQueue(int capacity) {
        this.capacity = capacity;
        this.queue = new Activity[capacity];
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    public void enqueue(Activity activity) {
        rear = (rear + 1) % capacity;
        queue[rear] = activity; // add new activity 

        if (size < capacity) { // as long as the size is less than the capacity add size 
            size++;
        } else {
            front = (front + 1) % capacity; // overwrites the oldest activity
        }
    }

    public Activity[] getAllActivities() {
        Activity[] result = new Activity[size];
        for (int i = 0; i < size; i++) {
            result[i] = queue[(front + i) % capacity];
        }
        return result;
    }
}



